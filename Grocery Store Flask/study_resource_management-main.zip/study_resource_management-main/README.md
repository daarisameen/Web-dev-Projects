# study_resource_management
App which helps students to manage study material
