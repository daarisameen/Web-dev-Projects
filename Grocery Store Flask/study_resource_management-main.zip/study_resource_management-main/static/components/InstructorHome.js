export default {
  template: `<div> Welcome Instructor</div>`,
}
