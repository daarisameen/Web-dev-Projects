export default {
  template: `<div> Welcome admin</div>`,
}
